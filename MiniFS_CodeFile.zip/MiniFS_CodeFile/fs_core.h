#ifndef FS_CORE_H
#define FS_CORE_H
void fs_init();
int fs_open(const char *filename);
int fs_write(const char *filename, const char *data);
int fs_read(const char *filename);
void fs_flush();
#endif