#ifndef CACHE_H
#define CACHE_H

#include "disk.h"

#define CACHE_SIZE 10
#define BLOCK_SIZE 1024

typedef struct {
    int block_num;
    char data[BLOCK_SIZE];
    int dirty;
    int valid;
} CacheBlock;

void init_cache();
char* read_from_cache(int block_num);
void write_to_cache(int block_num, const char *data);
void flush_cache();

#endif // CACHE_H
