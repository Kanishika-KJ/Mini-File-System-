#ifndef UTILS_H
#define UTILS_H
int allocate_block();
#endif