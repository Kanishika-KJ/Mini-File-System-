#include <stdio.h>
#include <string.h>
#include "fs_core.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: ./minifs [init|open|write|read|flush] [args...]\n");
        return 1;
    }
    fs_init();
    if (strcmp(argv[1], "init") == 0) {
        init_disk();
        printf("Disk initialized.\n");
    } else if (strcmp(argv[1], "open") == 0 && argc >= 3) {
        fs_open(argv[2]);
        printf("File '%s' opened.\n", argv[2]);
    } else if (strcmp(argv[1], "write") == 0 && argc >= 4) {
        fs_write(argv[2], argv[3]);
        printf("Data written to '%s'.\n", argv[2]);
    } else if (strcmp(argv[1], "read") == 0 && argc >= 3) {
        fs_read(argv[2]);
    } else if (strcmp(argv[1], "flush") == 0) {
        fs_flush();
    } else {
        printf("Invalid command or missing arguments.\n");
    }
    return 0;
}