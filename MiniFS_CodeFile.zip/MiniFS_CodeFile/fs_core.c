#include <stdio.h>
#include <string.h>
#include "fs_core.h"
#include "disk.h"
#include "cache.h"
#include "utils.h"

#define METADATA_FILE "metadata.bin"

typedef struct {
    char filename[32];
    int size;
    int blocks[10];
    int used;
} FileEntry;

static FileEntry table[100];

// Load metadata from file if exists
static void load_metadata() {
    FILE *fp = fopen(METADATA_FILE, "rb");
    if (fp) {
        fread(table, sizeof(table), 1, fp);
        fclose(fp);
        printf("Metadata loaded.\n");
    }
}

// Save metadata to file
static void save_metadata() {
    FILE *fp = fopen(METADATA_FILE, "wb");
    if (fp) {
        fwrite(table, sizeof(table), 1, fp);
        fclose(fp);
    }
}

// File system initialization
void fs_init() {
    memset(table, 0, sizeof(table));
    init_cache();
    load_metadata();  // Load saved metadata if available
}

// Open file, return index or allocate new one
int fs_open(const char *filename) {
    for (int i = 0; i < 100; i++) {
        if (table[i].used && strcmp(table[i].filename, filename) == 0)
            return i;
    }
    for (int i = 0; i < 100; i++) {
        if (!table[i].used) {
            strcpy(table[i].filename, filename);
            table[i].size = 0;
            memset(table[i].blocks, -1, sizeof(table[i].blocks));
            table[i].used = 1;
            return i;
        }
    }
    return -1;
}

// Write data to file and cache
int fs_write(const char *filename, const char *data) {
    int file_idx = fs_open(filename);
    if (file_idx == -1) return -1;

    FileEntry *f = &table[file_idx];
    int len = strlen(data);
    int blocks = (len + BLOCK_SIZE - 1) / BLOCK_SIZE;

    printf("Allocating %d blocks for file '%s'.\n", blocks, filename);
    if (blocks > 10) return -1;

    for (int i = 0; i < blocks; i++) {
        int blk = allocate_block();
        if (blk == -1) return -1;
        f->blocks[i] = blk;

        char temp[BLOCK_SIZE] = {0};
        strncpy(temp, data + i * BLOCK_SIZE, BLOCK_SIZE);
        write_to_cache(blk, temp);
        printf("Block %d allocated for data: '%s'\n", blk, temp);
    }

    f->size = len;
    save_metadata();
    return 0;
}

// Read file data from cache
int fs_read(const char *filename) {
    printf("Looking for file: '%s'\n", filename);
    for (int i = 0; i < 100; i++) {
        if (table[i].used) {
            printf("Checking entry %d: '%s'\n", i, table[i].filename);
            if (strcmp(table[i].filename, filename) == 0) {
                printf("Reading %s (%d bytes):\n", filename, table[i].size);
                for (int j = 0; j < 10 && table[i].blocks[j] != -1; j++) {
                    printf("Reading block %d...\n", table[i].blocks[j]);
                    char *d = read_from_cache(table[i].blocks[j]);
                    if (d) {
                        printf("Block data: %s\n", d);
                        fwrite(d, 1, BLOCK_SIZE, stdout);
                    }
                }
                printf("\n");
                return 0;
            }
        }
    }
    printf("File not found.\n");
    return -1;
}

// Flush cache and save metadata
void fs_flush() {
    flush_cache();
    save_metadata();
    printf("Metadata saved.\n");
}
