#include <string.h>
#include <stdio.h>
#include "cache.h"

static CacheBlock cache[CACHE_SIZE];

void init_cache() {
    for (int i = 0; i < CACHE_SIZE; i++) {
        cache[i].valid = 0;
        cache[i].dirty = 0;
    }
}

static int find_cache(int block_num) {
    for (int i = 0; i < CACHE_SIZE; i++)
        if (cache[i].valid && cache[i].block_num == block_num)
            return i;
    return -1;
}

static int find_empty() {
    for (int i = 0; i < CACHE_SIZE; i++)
        if (!cache[i].valid)
            return i;
    return -1;
}

char* read_from_cache(int block_num) {
    int idx = find_cache(block_num);
    if (idx != -1) return cache[idx].data;

    idx = find_empty();
    if (idx == -1) return NULL;

    read_block(block_num, cache[idx].data);
    cache[idx].block_num = block_num;
    cache[idx].valid = 1;
    cache[idx].dirty = 0;
    return cache[idx].data;
}

void write_to_cache(int block_num, const char *data) {
    int idx = find_cache(block_num);
    if (idx == -1) idx = find_empty();
    if (idx == -1) return;
    memcpy(cache[idx].data, data, BLOCK_SIZE);
    cache[idx].block_num = block_num;
    cache[idx].valid = 1;
    cache[idx].dirty = 1;
}

void flush_cache() {
    for (int i = 0; i < CACHE_SIZE; i++) {
        if (cache[i].valid && cache[i].dirty) {
            write_block(cache[i].block_num, cache[i].data);
            cache[i].dirty = 0;
            printf("Flushed block %d\n", cache[i].block_num);
        }
    }
}