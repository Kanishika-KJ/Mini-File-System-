#ifndef DISK_H
#define DISK_H
#define BLOCK_SIZE 1024
#define NUM_BLOCKS 1024
#define DISK_FILE "virtual_disk.bin"
int init_disk();
int read_block(int block_num, char *buf);
int write_block(int block_num, char *buf);
#endif