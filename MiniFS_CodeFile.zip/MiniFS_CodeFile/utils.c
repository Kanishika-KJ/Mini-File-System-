#include "disk.h"

int allocate_block() {
    static int next = 0;
    return (next < NUM_BLOCKS) ? next++ : -1;
}