#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "disk.h"

int init_disk() {
    FILE *fp = fopen(DISK_FILE, "wb");
    if (!fp) return -1;
    char block[BLOCK_SIZE] = {0};
    for (int i = 0; i < NUM_BLOCKS; i++)
        fwrite(block, sizeof(char), BLOCK_SIZE, fp);
    fclose(fp);
    return 0;
}

int read_block(int block_num, char *buf) {
    FILE *fp = fopen(DISK_FILE, "rb");
    if (!fp) return -1;
    fseek(fp, block_num * BLOCK_SIZE, SEEK_SET);
    fread(buf, BLOCK_SIZE, 1, fp);
    fclose(fp);
    return 0;
}

int write_block(int block_num, char *buf) {
    FILE *fp = fopen(DISK_FILE, "rb+");
    if (!fp) return -1;
    fseek(fp, block_num * BLOCK_SIZE, SEEK_SET);
    fwrite(buf, BLOCK_SIZE, 1, fp);
    fclose(fp);
    return 0;
}